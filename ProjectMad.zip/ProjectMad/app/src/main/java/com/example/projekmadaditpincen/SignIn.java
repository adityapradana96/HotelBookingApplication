package com.example.projekmadaditpincen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.projekmadaditpincen.DB.DBHelper;
import com.example.projekmadaditpincen.DB.Database;
import com.example.projekmadaditpincen.DB.Models.User;

import java.util.Vector;

public class SignIn extends AppCompatActivity {
    EditText email, password;
    Button login;

    int idMember;
    String telepon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        email = findViewById(R.id.email_edittext_signin);
        password = findViewById(R.id.password_edittetxt_signin);

        login = findViewById(R.id.signin_button_signin);

        Database.exampleSelect(SignIn.this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String valEmail = email.getText().toString();
                String valPassword = password.getText().toString();

                boolean result = false;

                for(int i = 0; i < Database.users.size(); i++){
                    if(valEmail.equals(Database.users.get(i).email) && valPassword.equals(Database.users.get(i).password)){
                        idMember = Database.users.get(i).id;
                        telepon = Database.users.get(i).telepon;
                        result = true;
                    }
                }

                if(email.getText().toString().isEmpty()) {
                    email.setError("Email must be filled !");
                }else if(password.getText().toString().isEmpty()){
                    password.setError("Password must be filled !");;
                }else if(result == false){
                    email.setError("Invalid Email ");
                    password.setError("Invalid Password");
                }
                else{
                    Toast.makeText(SignIn.this, "Login Successful" , Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignIn.this, HomeActivity.class);
                    intent.putExtra("idMember", idMember);
                    intent.putExtra("teleponMember", telepon);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
