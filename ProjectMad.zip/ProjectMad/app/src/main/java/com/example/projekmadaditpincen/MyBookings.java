package com.example.projekmadaditpincen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import com.example.projekmadaditpincen.Adapter.ListBookingAdapter;
import com.example.projekmadaditpincen.DB.Database;

import java.util.Vector;

public class MyBookings extends AppCompatActivity {

    public static Vector<String> namaHotel = new Vector<>();
    public static Vector<String> alamatHotel = new Vector<>();
    public static Vector<String> cekInHotel = new Vector<>();
    public static Vector<String> cekOutHotel = new Vector<>();
    public static Vector<String> totalPrice = new Vector<>();
    public static Vector<Integer> idBooking = new Vector<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_bookings);

        Intent getData = getIntent();
        int idMember = getData.getIntExtra("idMember", 0);

        ListView listBooking = findViewById(R.id.MyBookings_ListView_ListHotel);

        namaHotel.clear();
        alamatHotel.clear();
        cekInHotel.clear();
        cekOutHotel.clear();
        totalPrice.clear();
        idBooking.clear();

        for (int i = 0; i < Database.bookings.size(); i++){
            int nomorMemberBooking = Database.bookings.get(i).idMember;

            if (idMember == nomorMemberBooking){
                namaHotel.add(Database.hotels.get(Database.bookings.get(i).idHotel - 1).nameHotel);
                alamatHotel.add(Database.hotels.get(Database.bookings.get(i).idHotel - 1).addressHotel);
                cekInHotel.add(Database.bookings.get(i).checkInDate);
                cekOutHotel.add(Database.bookings.get(i).checkOutDate);
                totalPrice.add(Database.bookings.get(i).totalPrice);
                idBooking.add(Database.bookings.get(i).idBooking);
            }
        }

        Database.exampleSelect(MyBookings.this);

        ListBookingAdapter tampilinIsi = new ListBookingAdapter(MyBookings.this, idMember, namaHotel, alamatHotel, cekInHotel, cekOutHotel, totalPrice, idBooking);
        listBooking.setAdapter(tampilinIsi);
    }
}
