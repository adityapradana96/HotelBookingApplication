package com.example.projekmadaditpincen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projekmadaditpincen.DB.Database;

public class WelcomeActivity extends AppCompatActivity {
    public Button Signin, SignUp;
    WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        if(Database.chkDB(WelcomeActivity.this) == false){
            Database.generateFirstData(WelcomeActivity.this);
        }

        Database.sync(WelcomeActivity.this);

        webView = findViewById(R.id.imagewelcome);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        String file = "file:android_asset/resizedua.gif";
        webView.loadUrl(file);

        Signin = findViewById(R.id.button_login_welcome);
        SignUp = findViewById(R.id.button_signup_welcome);


        Signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, SignIn.class);
                startActivity(intent);
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, SignUp.class);
                startActivity(intent);
        }
        });
    }
}
