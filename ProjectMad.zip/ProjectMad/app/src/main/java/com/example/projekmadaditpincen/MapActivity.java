package com.example.projekmadaditpincen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap mapAPI;
    SupportMapFragment mapFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapAPI);
        mapFragment.getMapAsync(MapActivity.this);

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mapAPI = googleMap;

        Intent getData = getIntent();
        Double latHotel = getData.getDoubleExtra("latHotel", 0);
        Double longHotel = getData.getDoubleExtra("longHotel",0);
        String namaHotel = getData.getStringExtra("namaHotel");

        Log.d("Map", "" + latHotel + " " + longHotel);

        LatLng lokasiHotel = new LatLng(latHotel, longHotel);
        mapAPI.addMarker(new MarkerOptions().position(lokasiHotel).title(namaHotel));
        mapAPI.moveCamera(CameraUpdateFactory.newLatLng(lokasiHotel));
        mapAPI.setMinZoomPreference(14.0f);
        mapAPI.setMaxZoomPreference(28.0f);
    }
}
