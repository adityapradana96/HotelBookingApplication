package com.example.projekmadaditpincen.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projekmadaditpincen.BookingHotelActivity;
import com.example.projekmadaditpincen.DB.Database;
import com.example.projekmadaditpincen.DB.Models.Hotel;
import com.example.projekmadaditpincen.R;

import java.util.Vector;

public class ListHotelAdapter extends BaseAdapter {
    Context ctx;
    int idMember;
    String telepon;

    public ListHotelAdapter(Context ctx, int idMember, String telepon) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.telepon = telepon;
    }

    @Override
    public int getCount() {
        return Database.hotels.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.listhotel, null, false);

        final Hotel h = Database.hotels.get(position);

        TextView txtNamaHotel =v.findViewById(R.id.listHotel_NamaHotel_hotel1);
        TextView txtAlamatHotel =v.findViewById(R.id.listHotel_Address_hotel1);
        TextView txtPriceHotel = v.findViewById(R.id.listHotel_Price_hotel1);

        txtNamaHotel.setText(h.nameHotel);
        txtAlamatHotel.setText(h.addressHotel);
        txtPriceHotel.setText("Rp "+ h.priceHotel);

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bookingHotel = new Intent(ctx, BookingHotelActivity.class);
                bookingHotel.putExtra("h_idHotel", h.idHotel);
                bookingHotel.putExtra("h_namaHotel", h.nameHotel);
                bookingHotel.putExtra("h_priceHotel", h.priceHotel);
                bookingHotel.putExtra("h_phoneHotel", h.phonehotel);
                bookingHotel.putExtra("h_imageHotel", h.imageHotel);
                bookingHotel.putExtra("h_addressHotel", h.addressHotel);
                bookingHotel.putExtra("h_latHotel", h.latHotel);
                bookingHotel.putExtra("h_longHotel", h.longHotel);
                bookingHotel.putExtra("idMember", idMember);
                bookingHotel.putExtra("teleponMember", telepon);
                ctx.startActivity(bookingHotel);
            }
        });

        return v;
    }
}
