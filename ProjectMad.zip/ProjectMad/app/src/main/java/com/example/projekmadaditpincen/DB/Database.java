package com.example.projekmadaditpincen.DB;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.projekmadaditpincen.DB.Models.Booking;
import com.example.projekmadaditpincen.DB.Models.Hotel;
import com.example.projekmadaditpincen.DB.Models.User;
import com.example.projekmadaditpincen.HomeActivity;

import java.util.Vector;

public class Database {
    public static Vector<User> users = new Vector<>();
    public static Vector<Hotel> hotels = new Vector<>();
    public static Vector<Booking> bookings = new Vector<>();

    public static int hotelId, hotelPrice;
    public static String hotelNama, hotelPhone, hotelImage, hotelAddress;
    public static Double hotelLat, hotelLong;

    public static boolean HAS_SYNC = false;

    public static void insertUser(String nama, String email, String password, String telepon, Context ctx) {
        User u = new User(nama,email,password,telepon);
        u.id = users.size() + 1;
        users.add(u);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String query = String.format("INSERT INTO users(fullname, email, password, phonenumber) VALUES ('%s', '%s', '%s', '%s')", nama, email, password, telepon);
        db.execSQL(query);
    }

    public static void insertBooking(int idMember, int idHotel, String startDate, String endDate, String priceHotel, Context ctx){
        Booking b = new Booking(idMember, idHotel, startDate, endDate, priceHotel);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String queryBookings = "SELECT * FROM Bookings";
        Cursor c = db.rawQuery(queryBookings, null);

        if (c.moveToLast()){
            int i = c.getInt(0);
            b.idBooking = i + 1;
            bookings.add(b);

            String query = String.format("INSERT INTO Bookings(idBooking, id, idHotel, startDate, endDate, totalPrice) VALUES ('%d', '%d', '%d', '%s', '%s', '%s')", i+1, idMember, idHotel, startDate, endDate, priceHotel);
            db.execSQL(query);
        }else{
            b.idBooking = 1;
            bookings.add(b);

            String query = String.format("INSERT INTO Bookings(idBooking, id, idHotel, startDate, endDate, totalPrice) VALUES ('%d', '%d', '%d', '%s', '%s', '%s')", 1, idMember, idHotel, startDate, endDate, priceHotel);
            db.execSQL(query);
        }
    }

    public static void insertHotel(Vector<Integer> idHotel, Vector<String> nameHotel, Vector<Integer> priceHotel, Vector<String> phoneHotel, Vector<String> imageHotel, Vector<String> addressHotel, Vector<Double> latHotel, Vector<Double> longHotel, Context ctx){
        for(int i = 0; i < idHotel.size(); i++){
            hotelId = idHotel.get(i);
            hotelNama = nameHotel.get(i);
            hotelPrice = priceHotel.get(i);
            hotelPhone = phoneHotel.get(i);
            hotelImage = imageHotel.get(i);
            hotelAddress = addressHotel.get(i);
            hotelLat = latHotel.get(i);
            hotelLong = longHotel.get(i);

            Log.d("Ini data - data", String.format(""+ hotelNama + hotelPhone));
            Hotel h = new Hotel(hotelNama, hotelPrice, hotelPhone, hotelImage, hotelAddress, hotelLat, hotelLong);
            h.idHotel = hotelId;
            hotels.add(h);

            DBHelper helper = new DBHelper(ctx);
            SQLiteDatabase db = helper.getWritableDatabase();

            String query = String.format("INSERT INTO hotels(hotelImage, hotelName, hotelAddress, hotelPhone, hotelPrice, hotelLatitude, hotelLongtitude) VALUES ('%s', '%s', '%s', '%s', '%d', '%f', '%f')"
                    , hotelImage, hotelNama, hotelAddress, hotelPhone, hotelPrice, hotelLat, hotelLong);
            db.execSQL(query);

            Database.exampleSelect(ctx);
        }
    }

    public static boolean chkDB(Context ctx){
        String SQL_CHECK_USER = "SELECT * FROM users";
        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        Cursor c = db.rawQuery(SQL_CHECK_USER, null);
        if(c.moveToFirst()){
            return true;
        }
        return false;
    }

    public static boolean chkDBHotel(Context ctx){
        String SQL_CHECK_HOTEL = "SELECT * FROM hotels";
        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        Cursor c = db.rawQuery(SQL_CHECK_HOTEL, null);
        if(c.moveToFirst()){
            return true;
        }
        return false;
    }

    public static void generateFirstData(Context ctx){
        //New Admin
        int idAdmin = 1;
        String namaAdmin = "New Admin";
        String emailAdmin = "admin@gmail.com";
        String passwordAdmin = "Pika123";
        String teleponAdmin = "087880373678";
        User u = new User(namaAdmin,emailAdmin,passwordAdmin,teleponAdmin);
        u.id = idAdmin;
        users.add(u);

        //Lala Luna
        int idLala = 2;
        String namaLala = "Lala Luna";
        String emailLala = "lala@gmail.com";
        String passwordLala = "Luna345";
        String teleponLala = "081362112321";
        User u1 = new User(namaLala,emailLala,passwordLala,teleponLala);
        u1.id = idLala;
        users.add(u1);

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getWritableDatabase();

        String query1 = String.format("INSERT INTO users(fullname, email, password, phonenumber) VALUES ('%s', '%s', '%s', '%s')", namaAdmin, emailAdmin, passwordAdmin, teleponAdmin);
        String query2 = String.format("INSERT INTO users(fullname, email, password, phonenumber) VALUES ('%s', '%s', '%s', '%s')", namaLala, emailLala, passwordLala, teleponLala);
        db.execSQL(query1);
        db.execSQL(query2);

        //Booking1
        int idBooking1 = 1;
        int idMember1 = 1;
        int idHotel1 = 3;
        String startDate1 = "23/11/2019";
        String endDate1 = "24/11/2019";
        String totalPrice1 = "3509000";
        Booking b1 = new Booking(idMember1, idHotel1, startDate1, endDate1, totalPrice1);
        b1.idBooking = idBooking1;
        bookings.add(b1);

        //Booking2
        int idBooking2 = 2;
        int idMember2 = 1;
        int idHotel2 = 2;
        String startDate2 = "24/12/2019";
        String endDate2 = "28/12/2019";
        String totalPrice2 = "12105260";
        Booking b2 = new Booking(idMember2, idHotel2, startDate2, endDate2, totalPrice2);
        b2.idBooking = idBooking2;
        bookings.add(b2);

        //Booking3
        int idBooking3 = 3;
        int idMember3 = 2;
        int idHotel3 = 1;
        String startDate3 = "24/12/2019";
        String endDate3 = "25/12/2019";
        String totalPrice3 = "2896341";
        Booking b3 = new Booking(idMember3, idHotel3, startDate3, endDate3, totalPrice3);
        b3.idBooking = idBooking3;
        bookings.add(b3);

        String query3 = String.format("INSERT INTO Bookings(idBooking, id, idHotel, startDate, endDate, totalPrice) VALUES ('%d', '%d', '%d', '%s', '%s', '%s')", idBooking1, idMember1, idHotel1, startDate1, endDate1, totalPrice1);
        String query4 = String.format("INSERT INTO Bookings(idBooking, id, idHotel, startDate, endDate, totalPrice) VALUES ('%d', '%d', '%d', '%s', '%s', '%s')", idBooking2, idMember2, idHotel2, startDate2, endDate2, totalPrice2);
        String query5 = String.format("INSERT INTO Bookings(idBooking, id, idHotel, startDate, endDate, totalPrice) VALUES ('%d', '%d', '%d', '%s', '%s', '%s')", idBooking3, idMember3, idHotel3, startDate3, endDate3, totalPrice3);
        db.execSQL(query3);
        db.execSQL(query4);
        db.execSQL(query5);
    }

    public static boolean exampleSelect(Context ctx) {
        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getReadableDatabase();

        String queryBooking = "SELECT * FROM Bookings";

        Cursor c = db.rawQuery(queryBooking, null);

        int i = 0, n = 0, e = 0;
        String p = null, t = null, o = null;

        while (c.moveToNext()) {
            i = c.getInt(0);
            n = c.getInt(1);
            e = c.getInt(2);
            p = c.getString(3);
            t = c.getString(4);
            o = c.getString(5);

            Log.d("DATABASE", String.format("%d, %d, %d, %s, %s, %s", i, n, e, p, t, o));
        }

        c.close();
        return true;
    }

    public static void sync(Context ctx){
        if(HAS_SYNC){
            return;
        }

        HAS_SYNC = true;

        String SQL_SELECT_USER = "SELECT * FROM users";
        String SQL_SELECT_BOOKING = "SELECT * FROM Bookings";
        String SQL_SELECT_HOTEL = "SELECT * FROM hotels";

        DBHelper helper = new DBHelper(ctx);
        SQLiteDatabase db = helper.getReadableDatabase();

        Cursor c = db.rawQuery(SQL_SELECT_USER, null);
        while(c.moveToNext()){
            User u = new User(c.getString(1), c.getString(2), c.getString(3), c.getString(4));
            u.id = c.getInt(0);
            users.add(u);
        }
        c.close();

        Cursor c1 = db.rawQuery(SQL_SELECT_BOOKING, null);
        while(c1.moveToNext()){
            Booking b = new Booking(c1.getInt(1), c1.getInt(2), c1.getString(3), c1.getString(4), c1.getString(5));
            b.idBooking = c1.getInt(0);
            bookings.add(b);
        }
        c1.close();

        Cursor c2 = db.rawQuery(SQL_SELECT_HOTEL, null);
        while(c2.moveToNext()){
            Hotel h = new Hotel(c2.getString(2), c2.getInt(5), c2.getString(4), c2.getString(1), c2.getString(3), c2.getDouble(6), c2.getDouble(7));
            h.idHotel = c2.getInt(0);
            hotels.add(h);
        }
        c2.close();
    }
}
