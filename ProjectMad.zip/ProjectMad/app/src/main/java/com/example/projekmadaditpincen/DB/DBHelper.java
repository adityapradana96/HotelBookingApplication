package com.example.projekmadaditpincen.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static String DB_NAME = "hotelbooking";
    public static int DB_VERSION = 2;

    public static String SQL_CREATE_USERS_TABLE =
            "CREATE TABLE IF NOT EXISTS users(" +
                    "id integer primary key autoincrement," +
                    "fullname text," +
                    "email text," +
                    "password text," +
                    "phonenumber text" +
            ")";

    public static String SQL_CREATE_BOOKINGS_TABLE =
            "CREATE TABLE IF NOT EXISTS Bookings(" +
                    "idBooking integer primary key," +
                    "id integer references users (id)," +
                    "idHotel integer references hotels (idHotel)," +
                    "startDate text," +
                    "endDate text," +
                    "totalPrice text" +
            ")";

    public static String SQL_CREATE_HOTEL_TABLE =
            "CREATE TABLE IF NOT EXISTS hotels(" +
                    "idHotel integer primary key," +
                    "hotelImage text," +
                    "hotelName text," +
                    "hotelAddress text," +
                    "hotelPhone text," +
                    "hotelPrice integer," +
                    "hotelLatitude numeric," +
                    "hotelLongtitude numeric" +
            ")";

    public static String SQL_DROP_USERS_TABLE = "DROP TABLE IF EXISTS users";
    public static String SQL_DROP_BOOKINGS_TABLE = "DROP TABLE IF EXISTS bookings";
    public static String SQL_DROP_HOTEL_TABLE = "DROP TABLE IF EXISTS hotels";

    void refreshTable(SQLiteDatabase db) {
        db.execSQL(SQL_DROP_USERS_TABLE);
        db.execSQL(SQL_CREATE_USERS_TABLE);

        db.execSQL(SQL_DROP_BOOKINGS_TABLE);
        db.execSQL(SQL_CREATE_BOOKINGS_TABLE);

        db.execSQL(SQL_DROP_HOTEL_TABLE);
        db.execSQL(SQL_CREATE_HOTEL_TABLE);
    }

    public DBHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        refreshTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        refreshTable(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        refreshTable(db);
    }
}
