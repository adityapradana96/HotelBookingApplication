package com.example.projekmadaditpincen.DB.Models;

import java.util.Vector;

public class Hotel {
    public int idHotel, priceHotel;
    public String nameHotel, phonehotel, imageHotel, addressHotel;
    public Double latHotel, longHotel;

    public Hotel(String nameHotel, int priceHotel, String phonehotel, String imageHotel, String addressHotel, Double latHotel, Double longHotel){
        this.nameHotel = nameHotel;
        this.priceHotel = priceHotel;
        this.phonehotel = phonehotel;
        this.imageHotel = imageHotel;
        this.addressHotel = addressHotel;
        this.latHotel = latHotel;
        this.longHotel = longHotel;
    }
}
