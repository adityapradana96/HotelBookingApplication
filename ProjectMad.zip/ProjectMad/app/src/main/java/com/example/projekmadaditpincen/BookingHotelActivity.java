package com.example.projekmadaditpincen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.android.volley.toolbox.Volley;
import com.example.projekmadaditpincen.DB.DBHelper;
import com.example.projekmadaditpincen.DB.Database;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BookingHotelActivity extends AppCompatActivity{

    TextView txtNamaHotel, txtAlamatHotel, txtHargaHotel, txtPhoneHotel, txtCheckOutDate, txtCheckInDate, totalPrice;
    Date checkInDate, checkOutDate;
    Button btnCheckIn, btnCheckOut, btnBook, btnMap;

    final int SEND_SMS_PERMISSION_REQUEST_CODE = 1;

    void init(){
        txtNamaHotel = findViewById(R.id.namahotel_textview_detailhotel);
        txtAlamatHotel = findViewById(R.id.alamathotel_textview_detailhotel);
        txtHargaHotel = findViewById(R.id.harga_textview_detailhotel);
        txtPhoneHotel = findViewById(R.id.phone_textview_detailhotel);

        txtCheckInDate = findViewById(R.id.checkindate_textview_detail);
        txtCheckOutDate = findViewById(R.id.checkoutdate_textview_detail);

        btnCheckIn = findViewById(R.id.cekindate_button_detail);
        btnCheckOut = findViewById(R.id.cekotdate_button_detail);
        btnBook = findViewById(R.id.order_button_detail);

        totalPrice = findViewById(R.id.totalpembayaran_textview_detail);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_hotel);

        init();

        txtCheckInDate.addTextChangedListener(billTextWatcher);
        txtCheckOutDate.addTextChangedListener(billTextWatcher);

        Intent getData = getIntent();
        final int idMember = getData.getIntExtra("idMember", 0);
        final int idHotel = getData.getIntExtra("h_idHotel", 0);
        final String namaHotel = getData.getStringExtra("h_namaHotel");
        int priceHotel = getData.getIntExtra("h_priceHotel", 0);
        String phoneHotel = getData.getStringExtra("h_phoneHotel");
        String imageHotel = getData.getStringExtra("h_imageHotel");
        String alamatHotel = getData.getStringExtra("h_addressHotel");
        final Double latHotel = getData.getDoubleExtra("h_latHotel", 0);
        final Double longHotel = getData.getDoubleExtra("h_longHotel",0);
        final String telepon = getData.getStringExtra("teleponMember");

        txtNamaHotel.setText(namaHotel);
        txtAlamatHotel.setText(alamatHotel);
        txtHargaHotel.setText("Rp "+ String.valueOf(priceHotel));
        txtPhoneHotel.setText(phoneHotel);

        fetchBackgroundImage(imageHotel);

        if (checkPermission(Manifest.permission.SEND_SMS)){

        }else{
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE);
        }

        btnCheckIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog1();
            }
        });

        btnCheckOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog2();
            }
        });

        txtAlamatHotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent map = new Intent(BookingHotelActivity.this, MapActivity.class);
                map.putExtra("latHotel", latHotel);
                map.putExtra("longHotel", longHotel);
                map.putExtra("namaHotel", namaHotel);
                startActivity(map);
            }
        });



        btnBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dateCheckin = txtCheckInDate.getText().toString();
                String dateCheckOut = txtCheckOutDate.getText().toString();
                String totalHarga = totalPrice.getText().toString();

                if(checkPermission(Manifest.permission.SEND_SMS)){
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(telepon, null, "Thank you for booking our hotel" +"\n"+
                            "Hotel Name: "+ namaHotel +"\n"+
                            "Check In Date: "+ dateCheckin +"\n"+
                            "Check Out Date: "+ dateCheckOut +"\n"+
                            "Total Price: "+ totalHarga,
                            null, null);
                    Toast.makeText(BookingHotelActivity.this,"Thank you for booking our hotel", Toast.LENGTH_SHORT).show();

                    Database.insertBooking(idMember, idHotel, dateCheckin, dateCheckOut, totalHarga, BookingHotelActivity.this);
                    Database.exampleSelect(BookingHotelActivity.this);
                }else{
                    Toast.makeText(BookingHotelActivity.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }

                Intent home = new Intent(BookingHotelActivity.this, HomeActivity.class);
                home.putExtra("idMember", idMember);
                home.putExtra("teleponMember", telepon);
                startActivity(home);
                finish();
            }
        });
    }

    public void showDatePickerDialog1(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month+1) + "/" + year;

                init();

                Date currentDate = new Date();

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                String currentDateString = sdf.format(currentDate);

                try{
                    checkInDate = sdf.parse(date);
                }catch (Exception e){

                }

                if(compareDate(checkInDate, currentDate) < 0){
                    Toast.makeText(BookingHotelActivity.this, "Check in date must not before today", Toast.LENGTH_LONG).show();
                    txtCheckInDate.setText(currentDateString);
                }else if(checkOutDate != null && compareDate(checkOutDate, checkInDate) < 0 ){
                    Toast.makeText(BookingHotelActivity.this, "Check in date must not after check out date", Toast.LENGTH_LONG).show();
                    txtCheckOutDate.setText(currentDateString);
                    txtCheckInDate.setText(currentDateString);
                }else{
                    txtCheckInDate.setText(date);
                }
            }
        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    public void showDatePickerDialog2(){
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                String date = dayOfMonth + "/" + (month + 1) + "/" + year;

                init();

                Date currentDate = new Date();

                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                String currentDateString = sdf.format(currentDate);

                try {
                    checkOutDate = sdf.parse(date);
                } catch (Exception e) {

                }

                if(checkInDate == null){
                    Toast.makeText(BookingHotelActivity.this, "Check in date must be chosen first", Toast.LENGTH_LONG).show();
                }else if(compareDate(checkOutDate, currentDate) < 0){
                    Toast.makeText(BookingHotelActivity.this, "Check out date must not before today", Toast.LENGTH_LONG).show();
                    txtCheckOutDate.setText(currentDateString);
                }else if(compareDate(checkOutDate, checkInDate) < 0 ){
                    Toast.makeText(BookingHotelActivity.this, "Check out date must not before check in date", Toast.LENGTH_LONG).show();
                    txtCheckOutDate.setText(currentDateString);
                    txtCheckInDate.setText(currentDateString);
                }else{
                    txtCheckOutDate.setText(date);
                }
            }
        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    public long compareDate(Date date1, Date date2){
        long diff = (date1.getTime() - date2.getTime()) / 86400000;
        return diff;
    }

    private TextWatcher billTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            init();

            String dateCheckIn = txtCheckInDate.getText().toString();
            String dateCheckOut = txtCheckOutDate.getText().toString();

            btnCheckOut.setEnabled(!dateCheckIn.isEmpty());

            if(btnCheckOut.isEnabled()){
                btnCheckOut.setBackgroundResource(R.drawable.rounded_enabled_button);
            }else{
                btnCheckOut.setBackgroundColor(Color.parseColor("#CCCCCC"));
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            try{
                Date dateObj1 = sdf.parse(dateCheckIn);
                Date dateObj2 = sdf.parse(dateCheckOut);

                long diff = compareDate(dateObj2, dateObj1);

                String lamaHari = Long.toString(diff);

                if (diff == 0){
                    lamaHari = "1";
                }

                Intent getData = getIntent();
                final int priceHotel = getData.getIntExtra("h_priceHotel", 0);

                int parseHarga = priceHotel;
                int parseHari = Integer.parseInt(lamaHari);

                int totalHarga = parseHari * parseHarga;

                String hargaTotal2 = String.valueOf(totalHarga);

                totalPrice.setText("Rp. " + hargaTotal2);

                btnBook.setEnabled(!dateCheckIn.isEmpty() && !dateCheckOut.isEmpty());

                if(btnBook.isEnabled()){
                    btnBook.setBackgroundResource(R.drawable.rounded_enabled_button);
                }else{
                    btnBook.setBackgroundColor(Color.parseColor("#CCCCCC"));
                }

            }catch (Exception e){

            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void fetchBackgroundImage(String url){
        ImageRequest imgRequest = new ImageRequest(url, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                Drawable banner = new BitmapDrawable(response);
                findViewById(R.id.gambarhotel_imageView_detailhotel).setBackgroundDrawable(banner);
            }
        }, 256, 88, null, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println(error.getMessage().toString());
            }
        });
        RequestQueue rq = Volley.newRequestQueue(this);
        rq.add(imgRequest);
    }

    public boolean checkPermission(String permission){
        int check = ContextCompat.checkSelfPermission(this, permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
