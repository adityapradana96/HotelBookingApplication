package com.example.projekmadaditpincen.Adapter;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projekmadaditpincen.BookingHotelActivity;
import com.example.projekmadaditpincen.DB.DBHelper;
import com.example.projekmadaditpincen.DB.Database;
import com.example.projekmadaditpincen.DB.Models.Hotel;
import com.example.projekmadaditpincen.R;

import java.util.Vector;

public class ListBookingAdapter extends BaseAdapter {
    Context ctx;
    int idMember;

    public static Vector<String> namaHotel = new Vector<>();
    public static Vector<String> alamatHotel = new Vector<>();
    public static Vector<String> cekInHotel = new Vector<>();
    public static Vector<String> cekOutHotel = new Vector<>();
    public static Vector<String> totalPrice = new Vector<>();
    public static Vector<Integer> idBooking = new Vector<>();

    public ListBookingAdapter(Context ctx, int idMember, Vector<String> namaHotel, Vector<String> alamatHotel, Vector<String> cekInHotel,
                              Vector<String> cekOutHotel, Vector<String> totalPrice, Vector<Integer> idBooking) {
        this.ctx = ctx;
        this.idMember = idMember;
        this.namaHotel = namaHotel;
        this.alamatHotel = alamatHotel;
        this.cekInHotel = cekInHotel;
        this.cekOutHotel = cekOutHotel;
        this.totalPrice = totalPrice;
        this.idBooking = idBooking;
    }

    @Override
    public int getCount() {
        return namaHotel.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View booking = LayoutInflater.from(ctx).inflate(R.layout.listmybookings, null, false);

        TextView txtNamaHotel = booking.findViewById(R.id.listBook_NamaHotel_hotel1);
        TextView txtAlamatHotel = booking.findViewById(R.id.listBook_Address_hotel1);
        TextView txtCekInHotel = booking.findViewById(R.id.listBook_TextView_cekin);
        TextView txtCekOutHotel = booking.findViewById(R.id.listBook_TextView_cekot);
        TextView txtTotalPrice = booking.findViewById(R.id.listBook_TextView_total_semua);
        Button cancel = booking.findViewById(R.id.bookhotel_button_cancel);

        txtNamaHotel.setText(namaHotel.get(position));
        txtAlamatHotel.setText(alamatHotel.get(position));
        txtCekInHotel.setText(cekInHotel.get(position));
        txtCekOutHotel.setText(cekOutHotel.get(position));
        txtTotalPrice.setText(totalPrice.get(position));

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setMessage("Do you want to delete this booking?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        DBHelper helper = new DBHelper(ctx);
                        SQLiteDatabase db = helper.getWritableDatabase();

                        String query = String.format("DELETE FROM bookings WHERE idBooking = "+ idBooking.get(position));
                        db.execSQL(query);

                        for(int i = 0; i < Database.bookings.size(); i++){
                            if(idBooking.get(position) == Database.bookings.get(i).idBooking){
                                Database.bookings.remove(i);
                            }
                        }

                        namaHotel.remove(position);
                        alamatHotel.remove(position);
                        cekInHotel.remove(position);
                        cekOutHotel.remove(position);
                        totalPrice.remove(position);
                        idBooking.remove(position);

                        notifyDataSetChanged();

                        Database.exampleSelect(ctx);
                    }
                });

                builder.setNegativeButton("No", null);

                notifyDataSetChanged();

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return booking;
    }
}
