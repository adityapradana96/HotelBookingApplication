package com.example.projekmadaditpincen.DB.Models;

public class Booking {
    public int idBooking, idMember, idHotel;
    public String checkInDate, checkOutDate, totalPrice;

    public Booking(int idMember, int idHotel, String checkInDate, String checkOutDate, String totalPrice){
        this.idMember = idMember;
        this.idHotel = idHotel;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalPrice = totalPrice;
    }
}
