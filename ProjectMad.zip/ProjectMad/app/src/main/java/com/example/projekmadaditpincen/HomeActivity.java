package com.example.projekmadaditpincen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.projekmadaditpincen.Adapter.ListHotelAdapter;
import com.example.projekmadaditpincen.DB.Database;
import com.example.projekmadaditpincen.DB.Models.Hotel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Vector;


public class HomeActivity extends AppCompatActivity {

    ListView lvHotel;
    RequestQueue queue;

    ListHotelAdapter adapter;

    TextView cobaNamaHotel;

    String URL = "https://raw.githubusercontent.com/dnzrx/SLC-REPO/master/ISYS6203/E202-ISYS6203-LA01-00.json";

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menunya, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                Intent getData = getIntent();
                int idMember = getData.getIntExtra("idMember",0);

                Intent intent = new Intent(HomeActivity.this, MyBookings.class);
                intent.putExtra("idMember", idMember);
                startActivity(intent);
                return true;

            case R.id.item2:
                Intent intent1 = new Intent(HomeActivity.this, WelcomeActivity.class);
                startActivity(intent1);
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        lvHotel = findViewById(R.id.Home_ListView_ListHotel);
        cobaNamaHotel = findViewById(R.id.cobaNama);

        queue = Volley.newRequestQueue(HomeActivity.this);

        Intent getData = getIntent();
        int idMember = getData.getIntExtra("idMember",0);
        String telepon = getData.getStringExtra("teleponMember");

        Database.exampleSelect(HomeActivity.this);

        Log.d("Ini bates masuk JSON", String.format("84"));

        JsonArrayRequest request = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    Vector<Integer> vIdHotel = new Vector<>();
                    Vector<String> vNamaHotel = new Vector<>();
                    Vector<Integer> vPriceHotel = new Vector<>();
                    Vector<String> vPhoneHotel = new Vector<>();
                    Vector<String> vImageHotel = new Vector<>();
                    Vector<String> vAddressHotel = new Vector<>();
                    Vector<Double> vLatHotel = new Vector<>();
                    Vector<Double> vLongHotel = new Vector<>();

                    if (Database.hotels.isEmpty()){
                        for (int i = 0; i < response.length(); i++){
                            JSONObject obj = response.getJSONObject(i);
                            int idHotel = obj.getInt("id");
                            String namaHotel = obj.getString("name");
                            int priceHotel = obj.getInt("price_per_night");
                            String phoneHotel = obj.getString("phone_number");
                            String imagehotel = obj.getString("image");
                            String addressHotel = obj.getString("address");
                            Double latHotel = obj.getDouble("LAT");
                            Double longHotel = obj.getDouble("LNG");

                            vIdHotel.add(idHotel);
                            vNamaHotel.add(namaHotel);
                            vPriceHotel.add(priceHotel);
                            vPhoneHotel.add(phoneHotel);
                            vImageHotel.add(imagehotel);
                            vAddressHotel.add(addressHotel);
                            vLatHotel.add(latHotel);
                            vLongHotel.add(longHotel);
                        }

                        if(Database.chkDBHotel(HomeActivity.this) == false){
                            Database.insertHotel(vIdHotel, vNamaHotel, vPriceHotel, vPhoneHotel, vImageHotel, vAddressHotel, vLatHotel, vLongHotel, HomeActivity.this);
                        }
                    }
                    adapter.notifyDataSetChanged();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        queue.add(request);
        adapter = new ListHotelAdapter(HomeActivity.this, idMember, telepon);

        lvHotel.setAdapter(adapter);
    }
}
